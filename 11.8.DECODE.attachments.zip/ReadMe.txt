# DECODE
Dynamic ovErlapping COmmunity DEtection.

This repository contains implementations of the DECODE algorithm as described in: TODO.
As well as tools we used such as Omega-Index.

Under 'Tools' u can find our implementation to the Omega-Index calculating tool. 
Under 'ML' u can find the training set used to train the Random Tree used by DECODE.
